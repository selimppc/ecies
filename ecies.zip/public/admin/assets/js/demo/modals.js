/*
 * modals.js
 *
 * Demo JavaScript used for modals.
 */

"use strict";

$(document).ready(function(){

	//===== Modals & Dialogs =====//

	

});